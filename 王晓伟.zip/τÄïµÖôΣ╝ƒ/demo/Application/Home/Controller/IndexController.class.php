<?php
namespace Home\Controller;
use Think\Controller\RestController;
class IndexController extends RestController {
    public function index(){
        $this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} body{ background: #fff; font-family: "微软雅黑"; color: #333;font-size:24px} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.8em; font-size: 36px } a,a:hover{color:blue;}</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎使用 <b>ThinkPHP</b>！</p><br/>版本 V{$Think.version}</div><script type="text/javascript" src="http://ad.topthink.com/Public/static/client.js"></script><thinkad id="ad_55e75dfae343f5a1"></thinkad><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>','utf-8');
    }

    /**
     * Demo
     */
    public function demo(){
        switch ($this->_method){
            case 'get': // get请求处理代码
                $this->add();
                break;
            case 'post': // post请求处理代码
                $this->search();
                break;
        }
    }

    /**
     * 新增
     */
    public function add(){
        $data['name'] = I('name');
        $data['message'] = I('message');
        $data['create_time'] = $_SERVER['REQUEST_TIME'];
        M('user_message')->add($data);
    }

    /**
     * 查询
     */
    public function search(){
        //单次最少读取1条，最多20条
        $num = intval(I('num'));
        $num = $num ? $num : 10; //默认10条
        if ($num<1 || $num>20){
            exit('单次最少读取1条，最多20条');
        }

        $request_name = I('name'); //请求用户名称
        $final_id = intval(I('final_id'));
        $final_id = $final_id ? $final_id : 0;
        $where = array('name'=>$request_name,'id'=>array('gt',$final_id));

        //根据创建时间倒序
        $order = '';
        if (I('sort') == 'create_time_desc'){
            $order = 'create_time desc';
            $final_id ? $where['id'] = array('lt',$final_id) : '';
        }

        //获取新消息
        if (I('direction') == 'new'){
            if (I('sort') == 'create_time_desc'){ //倒序
                $final_id ? $where['id'] = array('gt',$final_id) : '';
            }
        }

        $lists = M('user_message')->where($where);
        $_lists = clone $lists;
        $total = $_lists->count(1);
        $lists = $lists->field('id, name, message')->limit($num)->order($order)->select();

        $this->ajaxReturn(array('data'=>$lists, 'final_id'=>$lists[$num-1]['id'], 'total'=>$total));

    }
}