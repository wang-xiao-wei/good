<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2009 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// |         lanfengye <zibin_5257@163.com>
// +----------------------------------------------------------------------

namespace Org\Util;

class Pagelist {

    // 分页栏每页显示的页数
    public $rollPage = 5;
    // 页数跳转时要带的参数
    public $parameter  ;
    // 分页URL地址
    public $url     =   '';
    // 默认列表每页显示行数
    public $listRows = 20;
    // 起始行数
    public $firstRow    ;
    // 分页总页面数
    protected $totalPages  ;
    // 总行数
    protected $totalRows  ;
    // 当前页数
    public $nowPage    ;
    // 分页的栏的总页数
    protected $coolPages   ;
    // 分页显示定制
    protected $config  =    array('header'=>'条记录','prev'=>'','next'=>'','first'=>'','last'=>'',
        'theme'=>'%first%%upPage%%linkPage%%downPage%%end%');
    // 默认分页变量名
    protected $varPage;

    protected $adjacentNum = 2; //两边页数

    /**
     * 架构函数
     * @access public
     * @param array $totalRows  总的记录数
     * @param array $listRows  每页显示记录数
     * @param array $parameter  分页跳转的参数
     */
    public function __construct($totalRows,$listRows='',$parameter='',$url='',$rollPage=5) {
        $this->totalRows    =   $totalRows;
        $this->parameter    =   $parameter;
        $this->rollPage    =   $rollPage;
        $this->varPage      =   C('VAR_PAGE') ? C('VAR_PAGE') : 'p' ;
        if(!empty($listRows)) {
            $this->listRows =   intval($listRows);
        }
        $this->totalPages   =   ceil($this->totalRows/$this->listRows);     //总页数
        $this->coolPages    =   ceil($this->totalPages/$this->rollPage);
        $this->nowPage      =   !empty($_REQUEST[$this->varPage])?intval($_REQUEST[$this->varPage]):1;
        if($this->nowPage<1){
            $this->nowPage  =   1;
        }elseif(!empty($this->totalPages) && $this->nowPage>$this->totalPages) {
            $this->nowPage  =   $this->totalPages;
        }
        $this->firstRow     =   $this->listRows*($this->nowPage-1);
    }

    public function setConfig($name,$value) {
        if(isset($this->config[$name])) {
            $this->config[$name]    =   $value;
        }
    }

    /**
     * 分页显示输出
     * @access public
     */
    public function show() {
        if(0 == $this->totalRows) return '';
        $p              =   $this->varPage;

        //if ($this->nowPage <= 10) {
            //$this->rollPage = 5;
        //}

        //$nowCoolPage    =   ceil(($this->nowPage - 10)/$this->rollPage);
        $nowCoolPage    =   ceil($this->nowPage /$this->rollPage);
        if ($nowCoolPage < 0) $nowCoolPage = 0;

        // 分析分页参数
        if($this->url){
            $depr       =   C('URL_PATHINFO_DEPR');
            $url        =   rtrim(U('/'.$this->url,'',false),$depr).$depr.'__PAGE__';
        }else{
            if($this->parameter && is_string($this->parameter)) {
                parse_str($this->parameter,$parameter);
            }elseif(is_array($this->parameter)){
                $parameter      =   $this->parameter;
            }elseif(empty($this->parameter)){
                unset($_GET[C('VAR_URL_PARAMS')]);
                $var =  I('get.');
                if(empty($var)) {
                    $parameter  =   array();
                }else{
                    $parameter  =   $var;
                }
                if ($_POST) {
                    foreach ($_POST as $k => $v) {
                        if(is_array($v)){
                            $parameter[$k] = join(',',$v);
                        }else{
                            $parameter[$k] = $v;
                        }
                    }
                }
            }
            $parameter[$p]  =   '__PAGE__';
            $param = array();
            foreach ($parameter as $k => $v) {
                $k = htmlspecialchars(addslashes(strip_tags($k)));
                $param[$k] = $v;
            }
            $url            =   U('',$param);
        }
        //上下翻页字符串
        if ($this->totalPages <= $this->rollPage) {
            $this->config['prev'] = '';
            $this->config['next'] = '';
        }

        $upRow          =   $this->nowPage-1;
        $downRow        =   $this->nowPage+1;
        if ($upRow>0){
            $upPage     =   "<a href='".str_replace('__PAGE__',$upRow,$url)."' class='prev'>".$this->config['prev']."</a>";
        }else{
            $upPage     =   "<a href='javascript:;' class='prev disabled'>".$this->config['prev']."</a>";
        }

        if ($downRow <= $this->totalPages){
            $downPage   =   "<a href='".str_replace('__PAGE__',$downRow,$url)."' class='next'>".$this->config['next']."</a>";
        }else{
            $downPage   =   "<a href='javascript:;' class='next disabled'>".$this->config['next']."</a>";
        }
        // << < > >>
        $theFirst   =   '';
        if($this->nowPage == 1)
            $prePage    =   '<a class="prev disabled ">上一页</a>';
        else
            $prePage    =   '<a href="'.str_replace('__PAGE__',($this->nowPage-1),$url).'" class="prev">上一页</a>';

        // 1 2 3 4 5
        $linkPage = "";
        //首先连开头
        $temp_now_page = $this->nowPage;
        $linkPage .= "<a class='cur'>".$temp_now_page."</a>";
        //逐个拼上左边页数
        for ($i = 0;$i < $this->adjacentNum;$i ++){
            $temp_now_page --;
            if($temp_now_page > 1){
                $linkPage = "<a href='".str_replace('__PAGE__',$temp_now_page,$url)."'>".$temp_now_page."</a>".$linkPage;
            }elseif($temp_now_page > 0){
                $linkPage = "<a href='".str_replace('__PAGE__',1,$url)."'>1</a>".$linkPage;
                break;
            }
        }
        //最后拼上的数大于2，就拼上省略号
        if($temp_now_page > 2){
            $linkPage = '<span class="dotted mgr5 mgl5">...</span>'.$linkPage;
            //再拼上1
            $linkPage = "<a href='".str_replace('__PAGE__',1,$url)."'>1</a>".$linkPage;
        }elseif ($temp_now_page > 1){
            //最后出来的数大于1就拼上1，能到这一步说明$temp_now_page是2
            $linkPage = "<a href='".str_replace('__PAGE__',1,$url)."'>1</a>".$linkPage;
        }else{
            //这个情况就不用拼了
        }

        //然后拼后面
        $temp_now_page = $this->nowPage;
        //逐个拼上右边页数
        for ($i = 0;$i < $this->adjacentNum;$i ++){
            $temp_now_page ++;
            if($temp_now_page < $this->totalPages){
                $linkPage .= "<a href='".str_replace('__PAGE__',$temp_now_page,$url)."'>".$temp_now_page."</a>";
            }elseif($temp_now_page <= $this->totalPages){
                $linkPage .= "<a href='".str_replace('__PAGE__',$this->totalPages,$url)."'>".$this->totalPages."</a>";
                break;
            }
        }
        //最后拼上的数小于倒数第二页，就拼上省略号
        if($temp_now_page < ($this->totalPages - 1)){
            $linkPage .= '<span class="dotted mgr5 mgl5">...</span>';
            //再拼上最后页
            $linkPage .= "<a href='".str_replace('__PAGE__',$this->totalPages,$url)."'>".$this->totalPages."</a>";
        }elseif ($temp_now_page < $this->totalPages){
            //最后出来的数小于最后页就拼上最后页，能到这一步说明$temp_now_page是倒数第二页
            $linkPage .= "<a href='".str_replace('__PAGE__',$this->totalPages,$url)."'>".$this->totalPages."</a>";
        }else{
            //这个情况就不用拼了
        }


//        if ($this->totalPages <= $this->rollPage) {
//            for($i=1;$i<=$this->rollPage;$i++){
//                if($i!=$this->nowPage){
//                    if($i<=$this->totalPages){
//                        $linkPage .= "<a href='".str_replace('__PAGE__',$i,$url)."'>".$i."</a>";
//                    }else{
//                        break;
//                    }
//                }else{
//                    $linkPage .= "<a class='cur'>".$i."</a>";
//                }
//            }
//        } else {
//            for($i=1;$i<=$this->rollPage;$i++){
//                if ($this->nowPage <= $this->rollPage) {
//                    $a = $this->nowPage - $this->rollPage;
//                    if ($a < 0) $a = 0;
//                    $page       =    $a + $i;
//                } else {
//                    $page       =   ($nowCoolPage - 1) * $this->rollPage + $i;
//                    if ($i == 1) {
//                        $link_first = '<a href="'.str_replace('__PAGE__',1,$url).'">1</a>';
//                        $linkPage .= $link_first . '<span class="dotted mgr5 mgl5">...</span>';
//                    }
//                }
//
//                if($page!=$this->nowPage){
//                    if($page<=$this->totalPages){
//                        $linkPage .= "<a href='".str_replace('__PAGE__',$page,$url)."'>".$page."</a>";
//                    }else{
//                        break;
//                    }
//                }else{
//                    if($this->totalPages != 1){
//                        $linkPage .= "<a class='cur'>".$page."</a>";
//                    }
//                }
//            }
//
//            if ($page < $this->totalPages) {
//                $linkPage .= '<span class="dotted mgr5 mgl5">...</span>' . "<a href='".str_replace('__PAGE__',$this->totalPages,$url)."'>".$this->totalPages."</a>";
//            }
//        }

        /* 根据页数显示分页效果（Zy） */
        if ($this->totalPages <= $this->rollPage) {
            $this->config['theme'] = '%upPage%%linkPage%%downPage%';
        }
        $confirm_url = preg_replace('/(.*)\/{1}([^\/]*)/i', '$1', $url).'/';
        if ($this->totalPages > 10) {
            $this->config['theme'] .= '<span class="mgr5 mgl5">到</span><input type="text" class=""><a data-url="'.str_replace('__PAGE__',$downRow,$confirm_url).'" href="" class="goto">确定</a><span class="mgr5">页</span>';
        }

        $pageStr     =   str_replace(
            array('%header%','%nowPage%','%totalRow%','%totalPage%','%upPage%','%downPage%','%first%','%prePage%','%linkPage%','%nextPage%','%end%'),
            array(
                $this->config['header'],
                $this->nowPage,
                $this->totalRows,
                $this->totalPages,
                $upPage,$downPage,$theFirst,$prePage,$linkPage,'', ''),$this->config['theme']);
        if ($this->totalPages == 1) $pageStr = '';
        return $pageStr;
    }

    /**
     * 获取总分页数
     * @return float
     * @author zhangbin
     */
    public function getTotalPages(){
        return $this->totalPages;
    }
}
